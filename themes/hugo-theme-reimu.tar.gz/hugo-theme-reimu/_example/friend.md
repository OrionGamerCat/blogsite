---
title: 友情链接
description: 友情链接

date: 2022-06-09T20:12:52+08:00
lastmod: 2022-06-09T20:12:52+08:00
---

## 本站信息

- 站名： 拔剑Sketon
- 站长： 拔剑Sketon

## 申请方法

- 添加本站后，在本页留言，格式如下

````yml
```yml
- name: #您的名字
  url: #您的网址
  desc: #简短描述
  image: #一张图片
```
````

## 小伙伴们

{{< friendsLink >}}
